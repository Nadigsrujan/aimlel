"""Neural Cartographer candidates package."""
