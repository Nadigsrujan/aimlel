"""Neural Cartographer labels package."""
