"""Neural Cartographer application package."""
