"""Neural Cartographer contracts package."""
