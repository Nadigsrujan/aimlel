"""Local ingestion job infrastructure."""
