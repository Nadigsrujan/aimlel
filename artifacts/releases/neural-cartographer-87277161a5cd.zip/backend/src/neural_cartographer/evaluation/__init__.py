"""Neural Cartographer evaluation package."""
