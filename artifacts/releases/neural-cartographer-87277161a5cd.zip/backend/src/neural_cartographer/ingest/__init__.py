"""Neural Cartographer ingest package."""
