"""Grounded evidence presentation."""
