"""Neural Cartographer graph package."""
